package Bookstore;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import Bookstore.Enums.PublicationTypes;
import Bookstore.Publications.Book;
import Bookstore.Publications.Magazine;
import Bookstore.Publications.Publication;
import Bookstore.Publications.Research;

public class BookstoreRunner {
	public static void main(String[] args) throws FileNotFoundException{
		Inventory bookStore = populatePublications();

		bookStore.listInventory();
	}

	public static Inventory populatePublications() throws FileNotFoundException{
		Inventory i = new Inventory();
		File infile = new File("./Data/items.tsv");
		Scanner input = new Scanner(infile);

		while(input.hasNextLine()){
			String productInfo = input.nextLine();
			if(!productInfo.isBlank()){
				i.addPublication(publicationFactory(productInfo));
			}
		}

		input.close();
		return i;
	}

	public static Publication publicationFactory(String dataString){
		String[] data = dataString.split("\t");

		switch(PublicationTypes.valueOf(data[0].toUpperCase())){
		
		case Book:
			return new Book(data[1], data[2], data[3], Integer.parseInt(data[4]));
			
		case Magazine:
			return new Magazine(data[1], data[2], data[3]);
			
		case Research:
			return new Research(data [1], data[2], data[3], Integer.parseInt(data[4]));
			
		case Publication:
			default:
				return new Publication(data[1], data[2]);
		
		}
		
	}
	

}

