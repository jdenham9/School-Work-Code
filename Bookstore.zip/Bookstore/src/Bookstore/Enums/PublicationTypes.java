package Bookstore.Enums;

public enum PublicationTypes {
	Book,
	Magazine,
	Research,
	Publication
}

