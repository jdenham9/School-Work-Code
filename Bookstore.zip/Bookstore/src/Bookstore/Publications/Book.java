package Bookstore.Publications;

public class Book extends Publication{
	private String author;
	private String publisher;
	private int publicationYear;
	private int pages;

	public Book(String genre, String title, String data, int pages) {
		super(title, genre);
		this.author = author;
		this.pages = pages;
	}

	public void printInfo() {
		System.out.printf("Book: %s - %s by %s (%d pages)\n",
				this.getGenre(), this.getTitle(), this.author, this.pages);
	}
}

