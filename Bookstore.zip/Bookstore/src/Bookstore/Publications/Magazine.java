package Bookstore.Publications;

public class Magazine extends Publication{
	private String issue;
	private int volume;
	private String publisher;

	public Magazine(String genre, String title, String issue) {
		super(title, genre);
		this.issue = issue;
	}

	public void printInfo() {
		System.out.printf("Magazine: %s - %s (Issue: %s)\n",
				this.getGenre(), this.getTitle(), this.issue);
	}
}

