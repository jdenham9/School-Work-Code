package Bookstore.Publications;

public class Publication implements Comparable<Publication>{
	protected String title;
	protected String genre;

	public Publication(String t, String g){
		title = t;
		genre = g;
	}
	
	public String getGenre() {
		return this.genre;
	}
		
	public String getTitle() {
		return this.title;
	}


	public void printInfo(){
		System.out.printf("%s :: %s%n", title, genre);
	}

	public int compareTo(Publication p) {
		int genreCompare = this.genre.compareTo(p.genre);
		if (genreCompare != 0) {
			return genreCompare;
		}
		
		return this.title.compareTo(p.title);
	}

}
