package Bookstore.Publications;

public class Research extends Publication{
	private String[] authors;
	private String journal;
	private int publicationYear;
	private int citations;
	private String institution;

	public Research(String genre, String title, String institution, int citations) {
		super(title, genre);
		this.institution = institution;
		this.citations = citations;
	}

	public void printInfo() {
		System.out.printf("Research: %s - %s (%s, %d citations)\n",
				this.getGenre(), this.getTitle(), this.institution, this.citations);
	}
}

