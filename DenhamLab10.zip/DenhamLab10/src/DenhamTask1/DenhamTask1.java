package DenhamTask1;

import java.util.Scanner;


public class DenhamTask1 {


public static void main(String[] args) {


Scanner input = new Scanner(System.in);

double[][][] temperatures = new double[3][7][4];


for (int city = 0; city < 3; city++) {

for (int day = 0; day < 7; day++) {

for (int time = 0; time < 4; time++) {

System.out.print("Enter temperature for City "

+ (city + 1) + ", Day " + (day + 1)

+ ", " + getTimeLabel(time) + ": ");

temperatures[city][day][time] = input.nextDouble();

}

}

}


for (int city = 0; city < 3; city++) {

double sum = 0;

for (int day = 0; day < 7; day++) {

for (int time = 0; time < 4; time++) {

sum += temperatures[city][day][time];

}

}

double avg = sum / 28;

System.out.printf("City %d average temperature: %.2f°C%n", (city + 1), avg);

}


double max = Double.MIN_VALUE;

int maxCity = 0, maxDay = 0, maxTime = 0;


for (int city = 0; city < 3; city++) {

for (int day = 0; day < 7; day++) {

for (int time = 0; time < 4; time++) {

if (temperatures[city][day][time] > max) {

max = temperatures[city][day][time];

maxCity = city;

maxDay = day;

maxTime = time;

}

}

}

}


System.out.printf("Highest temperature was %.1f°C recorded in City %d on Day %d at %s.%n",

max, maxCity + 1, maxDay + 1, getTimeLabel(maxTime));

}


public static String getTimeLabel(int index) {

if (index == 0) return "Morning";

if (index == 1) return "Noon";

if (index == 2) return "Afternoon";

return "Night";

}

}
