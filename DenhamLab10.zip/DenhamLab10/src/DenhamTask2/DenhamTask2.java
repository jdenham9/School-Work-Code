package DenhamTask2;

	import java.util.Scanner;


	public class DenhamTask2 {


	public static void main(String[] args) {


	Scanner input = new Scanner(System.in);

	int[][][] scores = new int[2][3][4];


	for (int dept = 0; dept < 2; dept++) {

	for (int student = 0; student < 3; student++) {

	for (int exam = 0; exam < 4; exam++) {

	System.out.print("Enter score for Department "

	+ (dept + 1) + ", Student "

	+ (student + 1) + ", Exam "

	+ (exam + 1) + ": ");

	scores[dept][student][exam] = input.nextInt();

	}

	}

	}


	for (int dept = 0; dept < 2; dept++) {

	for (int student = 0; student < 3; student++) {

	int sum = 0;

	for (int exam = 0; exam < 4; exam++) {

	sum += scores[dept][student][exam];

	}

	double avg = sum / 4.0;

	System.out.printf("Student %d in Department %d - Average Score: %.1f%n",

	student + 1, dept + 1, avg);

	}

	}


	for (int dept = 0; dept < 2; dept++) {

	int sum = 0;

	for (int student = 0; student < 3; student++) {

for (int exam = 0; exam < 4; exam++) {

sum += scores[dept][student][exam];

	}

}

double avg = sum / 12.0;

System.out.printf("Department %d - Average Score: %.1f%n",

dept + 1, avg);

	}


int max = Integer.MIN_VALUE;

int maxDept = 0, maxStudent = 0, maxExam = 0;


for (int dept = 0; dept < 2; dept++) {

for (int student = 0; student < 3; student++) {

for (int exam = 0; exam < 4; exam++) {

if (scores[dept][student][exam] > max) {

max = scores[dept][student][exam];

maxDept = dept;

maxStudent = student;

maxExam = exam;

			}

		}

	}

}


	System.out.printf("Highest exam score was %d by Student %d in Department %d on Exam %d.%n",

max, maxStudent + 1, maxDept + 1, maxExam + 1);

	}

}
