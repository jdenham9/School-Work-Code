package DenhamTask1;

	import java.util.Scanner;

	public class DenhamTask1 {
	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);

	        Rectangle r1 = new Rectangle();

	        System.out.print("Enter width for rectangle 2: ");
	        double w = input.nextDouble();
	        System.out.print("Enter height for rectangle 2: ");
	        double h = input.nextDouble();

	        Rectangle r2 = new Rectangle(w, h);

	        System.out.println("Rectangle 1 Area: " + r1.getArea());
	        System.out.println("Rectangle 1 Perimeter: " + r1.getPerimeter());

	        System.out.println("Rectangle 2 Area: " + r2.getArea());
	        System.out.println("Rectangle 2 Perimeter: " + r2.getPerimeter());
	    }
	}

