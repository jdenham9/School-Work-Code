package DenhamTask2;

public class DenhamTask2 {

	public class BankAccount {
	    private String accountNumber;
	    private String accountHolder;
	    private double balance;

	    public BankAccount(String accountNumber, String accountHolder, double balance) {
	        this.accountNumber = accountNumber;
	        this.accountHolder = accountHolder;
	        this.balance = balance;
	    }

	    public void deposit(double amount) {
	        balance += amount;
	    }

	    public void withdraw(double amount) {
	        if (amount <= balance) {
	            balance -= amount;
	        }
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public String getAccountInfo() {
	        return accountHolder + " (" + accountNumber + ")";
	    }
	}

}
