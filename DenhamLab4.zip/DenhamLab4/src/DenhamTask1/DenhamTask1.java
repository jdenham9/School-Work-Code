package DenhamTask1;

public class DenhamTask1 {

	public static void main(String[] args) {
		        int length = 5;          
		        int width = 10;           
		        int threshold = 40;       
		       
		        int area = length * width; 
		       
    	boolean isAboveThreshold = area < threshold; 
		        System.out.println("Area = " + area);
		        System.out.println("Threshold = " + threshold);
		        System.out.println("isAboveThreshold = " + isAboveThreshold);
		        if (isAboveThreshold) {
		            System.out.println("Area is above threshold.");
		        } else {
		            System.out.println("Area is NOT above threshold.");
		        }
		    }
		

	}


