package DenhamTask2;

import java.util.Scanner;

public class DenhamTask2 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter side a: ");
			double a = input.nextDouble();
			
		System.out.print("Enter side b: ");
			double b = input.nextDouble();
			
			double c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));

			double angleA = Math.toDegrees(Math.atan(a / b));
			double angleB = 90 - angleA;
			
		System.out.println("Hypotenuse: " + c);
		System.out.println("Angle A: " + angleA + " degrees");
		System.out.println("Angle B: " + angleB + " degrees");
		
		input.close();
	}

}
