package DenhamTask3;

public class DenhamTask3 {

	public static void main(String[] args) {
		int lotteryNumber = (int)(Math.random() * 900) + 100;
		
	System.out.println("Lotter number: " + lotteryNumber);
	}

}
