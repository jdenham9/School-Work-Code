package DenhamTask4;

import java.util.Scanner;

public class DenhamTask4 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		String lottery = "" + (int)(Math.random() * 10) + (int)(Math.random() * 10);
		
		System.out.print("Enter your lottery pick (two digits): ");
		String guess = input.nextLine();
		
		System.out.println("The lottery number is " + lottery);
		
		if (guess.equals(lottery)) {
			System.out.println("Exact match: you win $10,000");
		}
		else if (guess.charAt(0) == lottery.charAt(1) && guess.charAt(1) == lottery.charAt(0)) {
			System.out.println("Match all digits: you win $3,000");
		}
		else if (lottery.contains("" + guess.charAt(0)) || lottery.contains("" + guess.charAt(1))) {
			System.out.println("Match one digit: you win $1,000");
		}
		else {
			System.out.println("Sorry, no match.");
			
		}
		
		input.close();
	
			
		}
		

	}


