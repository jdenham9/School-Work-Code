import java.util.Scanner;

public class DenhamTask1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        final double TAX_RATE = 0.0825;

        String item1, item2, item3;
        int qty1, qty2, qty3;
        double price1, price2, price3;

        System.out.print("Enter name of item 1: ");
        item1 = input.nextLine();
        System.out.print("Enter quantity of item 1: ");
        qty1 = input.nextInt();
        System.out.print("Enter price per unit of item 1: ");
        price1 = input.nextDouble();
        input.nextLine(); 

        System.out.print("Enter name of item 2: ");
        item2 = input.nextLine();
        System.out.print("Enter quantity of item 2: ");
        qty2 = input.nextInt();
        System.out.print("Enter price per unit of item 2: ");
        price2 = input.nextDouble();
        input.nextLine();

        System.out.print("Enter name of item 3: ");
        item3 = input.nextLine();
        System.out.print("Enter quantity of item 3: ");
        qty3 = input.nextInt();
        System.out.print("Enter price per unit of item 3: ");
        price3 = input.nextDouble();

        double total1 = qty1 * price1;
        double total2 = qty2 * price2;
        double total3 = qty3 * price3;
        double subtotal = total1 + total2 + total3;
        double tax = subtotal * TAX_RATE;
        double finalTotal = subtotal + tax;

        System.out.println("\n================= GROCERY STORE RECEIPT =================");
        System.out.printf("%-15s %5s %10s %12s%n", "Item", "Qty", "Unit Price", "Total");
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-15s %5d %10.2f %12.2f%n", item1, qty1, price1, total1);
        System.out.printf("%-15s %5d %10.2f %12.2f%n", item2, qty2, price2, total2);
        System.out.printf("%-15s %5d %10.2f %12.2f%n", item3, qty3, price3, total3);
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-33s %12.2f%n", "Subtotal:", subtotal);
        System.out.printf("%-33s %12.2f%n", "Tax (8.25%):", tax);
        System.out.printf("%-33s %12.2f%n", "Total:", finalTotal);
        System.out.println("==========================================================");
    }
}
