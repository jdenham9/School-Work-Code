package DenhamTask2;
import java.util.Scanner;

import java.util.Random;

public class DenhamTask2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        // Generate random number between 1 and 100
        int secretNumber = rand.nextInt(100) + 1;
        int guess = 0;
        int attempts = 0;

        System.out.println("Guess a number between 1 and 100");

        // Loop until user guesses correctly
        while (guess != secretNumber) {
            System.out.print("Enter your guess: ");
            guess = input.nextInt();
            attempts++;

            if (guess > secretNumber) {
                System.out.println("Too high. Try again.");
            } else if (guess < secretNumber) {
                System.out.println("Too low. Try again.");
            } else {
                System.out.printf("Congratulations! You guessed the number %d in %d attempts.%n",
                        secretNumber, attempts);
            }
        }

        input.close();
    }
}