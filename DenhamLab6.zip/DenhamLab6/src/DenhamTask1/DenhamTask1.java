package DenhamTask1;

import java.util.Scanner;

public class DenhamTask1 {
	   public static void main(String[] args) {
	       Scanner input = new Scanner(System.in);
	        int choice;
	        double num1, num2, result;

	        do {
	            // Display menu
	            System.out.println("\n===== Simple Calculator =====");
	            System.out.println("1. Add");
	            System.out.println("2. Subtract");
	            System.out.println("3. Multiply");
	            System.out.println("4. Divide");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice: ");
	            choice = input.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter first number: ");
	                    num1 = input.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = input.nextDouble();
	                    result = num1 + num2;
	                    System.out.println("Result: " + result);
	                    break;

	                case 2:
	                    System.out.print("Enter first number: ");
	                    num1 = input.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = input.nextDouble();
	                    result = num1 - num2;
	                    System.out.println("Result: " + result);
	                    break;

	                case 3:
	                    System.out.print("Enter first number: ");
	                    num1 = input.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = input.nextDouble();
	                    result = num1 * num2;
	                    System.out.println("Result: " + result);
	                    break;

	                case 4:
	                    System.out.print("Enter first number: ");
	                    num1 = input.nextDouble();
	                    System.out.print("Enter second number: ");
	                    num2 = input.nextDouble();
	                    if (num2 != 0) {
	                        result = num1 / num2;
	                        System.out.println("Result: " + result);
	                    } else {
	                        System.out.println("Error: Cannot divide by zero!");
	                    }
	                    break;

	                case 5:
	                    System.out.println("Exiting calculator. Goodbye!");
	                    break;

	                default:
	                    System.out.println("Invalid choice! Please enter a number between 1 and 5.");
	            }
	        } while (choice != 5);

	        input.close();
	    }
	


	}


