
package DenhamTask1;

import java.util.Scanner;

public class DenhamTask1 {

	import java.util.Scanner;

	    public static double celsiusToFahrenheit(double celsius) {
	        return (celsius * 9 / 5) + 32;
	    }

	    public static double fahrenheitToCelsius(double fahrenheit) {
	        return (fahrenheit - 32) * 5 / 9;
	    }

	    public static void displayResult(double celsius, double fahrenheit) {
	        System.out.printf("Celsius: %.2f°C%n", celsius);
	        System.out.printf("Fahrenheit: %.2f°F%n", fahrenheit);
	    }

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);

	        System.out.println("Temperature Converter");
	        System.out.println("---------------------");
	        System.out.println("Choose conversion type:");
	        System.out.println("1. Celsius to Fahrenheit");
	        System.out.println("2. Fahrenheit to Celsius");
	        System.out.print("Enter your choice (1 or 2): ");
	        int choice = input.nextInt();

	        if (choice == 1) {
	            System.out.print("Enter temperature in Celsius: ");
	            double celsius = input.nextDouble();

	            if (celsius < -273.15) {
	                System.out.println("Error: Temperature cannot be below absolute zero (-273.15°C).");
	            } else {
	                double fahrenheit = celsiusToFahrenheit(celsius);
	                displayResult(celsius, fahrenheit);
	            }

	        } else if (choice == 2) {
	            System.out.print("Enter temperature in Fahrenheit: ");
	            double fahrenheit = input.nextDouble();

	            if (fahrenheit < -459.67) {
	                System.out.println("Error: Temperature cannot be below absolute zero (-459.67°F).");
	            } else {
	                double celsius = fahrenheitToCelsius(fahrenheit);
	                displayResult(celsius, fahrenheit);
	            }

	        } else {
	            System.out.println("Invalid choice! Please enter 1 or 2.");
	        }

	        input.close();
	    
	}



}
