package DenhamTask2;

import java.util.Scanner;

public class DenhamTask2 {

	
		public static double calculateFutureBalance(double principal, double rate, int years) {
	        return principal * Math.pow(1 + rate / 100, years);
	    }

	    public static void displayBalance(double principal, double rate, int years, double futureBalance) {
	        System.out.printf("Initial Balance: $%.2f%n", principal);
	        System.out.printf("Annual Interest Rate: %.2f%%%n", rate);
	        System.out.printf("Years: %d%n", years);
	        System.out.printf("Future Balance: $%.2f%n", futureBalance);
	    }

	    public static void increaseRate(double rate) {
	        rate += 1;
	        System.out.printf("New increased rate (inside method): %.2f%%%n", rate);
	    }

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);

	        System.out.print("Enter initial balance: ");
	        double principal = input.nextDouble();

	        System.out.print("Enter annual interest rate (in %): ");
	        double rate = input.nextDouble();

	        System.out.print("Enter number of years: ");
	        int years = input.nextInt();

	        if (principal <= 0 || rate < 0 || years <= 0) {
	            System.out.println("Error: Balance must be > 0, rate ≥ 0, and years > 0.");
	        } else {
	            double futureBalance = calculateFutureBalance(principal, rate, years);
	            displayBalance(principal, rate, years, futureBalance);

	            increaseRate(rate);
	            System.out.printf("Original rate after method call (unchanged): %.2f%%%n", rate);
	        }

	        input.close();
	    

	}

}
