package DenhamTask1;

import java.util.Random;

public class DenhamTask1 {
    static int[] deck = new int[52];
    static String[] suits = {"Spades", "Hearts", "Diamonds", "Clubs"};
    static String[] ranks = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
    private static Random random = new Random();

    public static void initializeDeck() {
        for (int i = 0; i < deck.length; i++) {
            deck[i] = i;
        }
    }

    public static void shuffleDeck() {
        for (int i = deck.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            int temp = deck[i];
            deck[i] = deck[j];
            deck[j] = temp;
        }
    }

    public static String getCardDescription(int cardNumber) {
        String rank = ranks[cardNumber % 13];
        String suit = suits[cardNumber / 13];
        return rank + " of " + suit;
    }

    public static int[] drawCards(int numCards) {
        if (numCards > 52) numCards = 52;
        int[] drawnCards = new int[numCards];
        shuffleDeck();
        for (int i = 0; i < numCards; i++) {
            drawnCards[i] = deck[i];
        }
        return drawnCards;
    }
}
