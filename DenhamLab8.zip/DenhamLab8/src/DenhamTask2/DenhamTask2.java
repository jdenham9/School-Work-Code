package DenhamTask2;

import java.util.Scanner;

public class DenhamTask2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DeckOperations.initializeDeck();

        while (true) {
            System.out.print("Enter number of cards to draw (1-52) or 0 to exit: ");
            int numCards = scanner.nextInt();
            if (numCards == 0) break;
            if (numCards < 1 || numCards > 52) {
                System.out.println("Invalid number. Please enter a number between 1 and 52.");
                continue;
            }

            int[] drawnCards = DeckOperations.drawCards(numCards);
            System.out.println("Drawn cards:");
            for (int card : drawnCards) {
                System.out.println(DeckOperations.getCardDescription(card));
            }
            System.out.println();
        }

        System.out.println("Goodbye!");
        scanner.close();
    }
}

