package DenhamTask1;
	
	import java.util.Scanner;

	public class DenhamTask1 {
	
	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);

	        int[][] matrix1 = new int[3][3];
	        int[][] matrix2 = new int[3][3];

	        System.out.println("Enter the first 3x3 matrix:");
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	                matrix1[i][j] = input.nextInt();
	            }
	        }

	        System.out.println("Enter the second 3x3 matrix:");
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	                matrix2[i][j] = input.nextInt();
	            }
	        }

	        int[][] result = multiplyMatrix(matrix1, matrix2);

	        System.out.println("Resulting Matrix:");
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	                System.out.print(result[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }

	    public static int[][] multiplyMatrix(int[][] a, int[][] b) {
	        int[][] result = new int[3][3];

	        for (int row = 0; row < 3; row++) {
	            for (int col = 0; col < 3; col++) {
	                result[row][col] =
	                      a[row][0] * b[0][col]
	                    + a[row][1] * b[1][col]
	                    + a[row][2] * b[2][col];
	            }
	        }

	        return result;
	    }
	}


