package DenhamTask2;

public class DenhamTask2 { 

	    public static void main(String[] args) {

	        char[][] answers = {
	            {'A','B','A','C','C','D','E','E','A','D'},
	            {'D','B','A','B','C','A','E','E','A','D'},
	            {'E','D','D','A','C','B','E','E','A','D'},
	            {'C','B','A','E','D','C','E','E','A','D'},
	            {'A','B','D','C','C','D','E','E','A','D'},
	            {'B','B','E','C','C','D','E','E','A','D'},
	            {'B','B','A','C','C','D','E','E','A','D'},
	            {'E','B','E','C','C','D','E','E','A','D'}
	        };

	        char[] key = {'D','B','D','C','C','D','A','E','A','D'};

	        int[][] results = new int[8][2];

	        for (int i = 0; i < answers.length; i++) {
	            int correct = 0;

	            for (int j = 0; j < answers[i].length; j++) {
	                if (answers[i][j] == key[j]) {
	                    correct++;
	                }
	            }

	            results[i][0] = i;
	            results[i][1] = correct;
	        }

	        for (int i = 0; i < results.length - 1; i++) {
	            for (int j = i + 1; j < results.length; j++) {
	                if (results[j][1] < results[i][1]) {
	                    int[] temp = results[i];
	                    results[i] = results[j];
	                    results[j] = temp;
	                }
	            }
	        }

	        System.out.println("Student results (lowest to highest):");
	        for (int i = 0; i < results.length; i++) {
	            System.out.println("Student " + results[i][0] + ": " +
	                               results[i][1] + " correct");
	        }
	    }
	}

