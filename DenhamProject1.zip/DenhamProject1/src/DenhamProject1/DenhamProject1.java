package DenhamProject1;

import java.util.Scanner;

public class DenhamProject1 {
		  public static void main(String[] args) {
		  Scanner input = new Scanner(System.in);

		        int numStudents;
		        String studentName;
		        double score;
		        String grade;
		        String studentData = "";

		        double highest = -1;
		        double lowest = 101;
		        double sumScores = 0;
		        double sumSquares = 0;

		        System.out.print("Enter the number of students: ");
		        numStudents = input.nextInt();
		        input.nextLine();

		        int count = 0;
		        while (count < numStudents) {
		            System.out.print("Enter student name: ");
		            studentName = input.nextLine();

		            while (true) {
		                System.out.print("Enter score (0 - 100): ");
		                score = input.nextDouble();
		                input.nextLine();

		                if (score >= 0 && score <= 100) {
		                    break;
		                } else {
		                    System.out.println("Invalid score. Please enter a value between 0 and 100.");
		                }
		            }

		            if (score >= 90) grade = "A";
		            else if (score >= 80) grade = "B";
		            else if (score >= 70) grade = "C";
		            else if (score >= 60) grade = "D";
		            else grade = "F";

		            studentData += String.format("%-15s %-10.2f %-10s\n", studentName, score, grade);

		            if (score > highest) highest = score;
		            if (score < lowest) lowest = score;
		            sumScores += score;
		            sumSquares += score * score;

		            count++;
		        }

		        double average = sumScores / numStudents;
		        double variance = (sumSquares / numStudents) - (average * average);
		        double stdDeviation = Math.sqrt(variance);

		        System.out.println("\n========== STUDENT GRADE REPORT ==========");
		        System.out.printf("%-15s %-10s %-10s\n", "Name", "Score", "Grade");
		        System.out.println("------------------------------------------");
		        System.out.print(studentData);
		        System.out.println("------------------------------------------");
		        System.out.printf("Highest Score: %.2f\n", highest);
		        System.out.printf("Lowest Score: %.2f\n", lowest);
		        System.out.printf("Average Score: %.2f\n", average);
		        System.out.printf("Standard Deviation: %.2f\n", stdDeviation);

		        String searchName;
		        boolean found;
		        System.out.println("\n========== STUDENT SEARCH ==========");
		        while (true) {
		            System.out.print("Enter a student name to search (or 'exit' to quit): ");
		            searchName = input.nextLine();

		            if (searchName.equalsIgnoreCase("exit")) {
		                System.out.println("Exiting search...");
		                break;
		            }

		            Scanner dataScanner = new Scanner(studentData);
		            found = false;
		            while (dataScanner.hasNextLine()) {
		                String line = dataScanner.nextLine();
		                if (line.toLowerCase().startsWith(searchName.toLowerCase() + " ")) {
		                    System.out.println("Student found: " + line);
		                    found = true;
		                    break;
		                }
		            }

		            if (!found) {
		                System.out.println("Student not found.");
		            }
		        }

		        input.close();
		    }
		}

	


