package DenhamProject2;

import java.util.Scanner;

public class DenhamProject2;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("How many students would you like to enter? ");
        int count = input.nextInt();
        input.nextLine();

        String[] names = enterNames(count, input);
        double[] scores = enterScores(count, input);

        double max = findMax(scores);
        double min = findMin(scores);
        double average = computeAverage(scores);
        double stdDev = computeStandardDeviation(scores, average);

        char[] grades = assignLetterGrades(scores);

        printStudentTable(names, scores, grades);
        printStatistics(max, min, average, stdDev);

        searchStudentLoop(names, scores, grades, input);
    }

    public static String[] enterNames(int count, Scanner input) {
        String[] names = new String[count];
        for (int i = 0; i < count; i++) {
            System.out.print("Name of student " + (i + 1) + ": ");
            names[i] = input.nextLine();
        }
        return names;
    }

    public static double[] enterScores(int count, Scanner input) {
        double[] scores = new double[count];
        for (int i = 0; i < count; i++) {
            while (true) {
                System.out.print("Score for " + (i + 1) + ": ");
                double score = input.nextDouble();
                if (score >= 0 && score <= 100) {
                    scores[i] = score;
                    break;
                }
                System.out.println("Invalid score! Must be between 0 and 100.");
            }
        }
        input.nextLine();
        return scores;
    }

    public static double findMax(double[] scores) {
        double max = scores[0];
        for (double s : scores) if (s > max) max = s;
        return max;
    }

    public static double findMin(double[] scores) {
        double min = scores[0];
        for (double s : scores) if (s < min) min = s;
        return min;
    }

    public static double computeAverage(double[] scores) {
        double sum = 0;
        for (double s : scores) sum += s;
        return sum / scores.length;
    }

    public static double computeStandardDeviation(double[] scores, double average) {
        double sumSquares = 0;
        for (double s : scores) sumSquares += Math.pow(s - average, 2);
        return Math.sqrt(sumSquares / scores.length);
    }

    public static char[] assignLetterGrades(double[] scores) {
        char[] grades = new char[scores.length];
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] >= 90) grades[i] = 'A';
            else if (scores[i] >= 80) grades[i] = 'B';
            else if (scores[i] >= 70) grades[i] = 'C';
            else if (scores[i] >= 60) grades[i] = 'D';
            else grades[i] = 'F';
        }
        return grades;
    }

    public static void printStudentTable(String[] names, double[] scores, char[] grades) {
        System.out.println("\n----------------------------------------------------");
        System.out.println("                 Student Grade Table");
        System.out.println("----------------------------------------------------");
        System.out.printf("%-20s %-10s %-10s%n", "Name", "Score", "Grade");
        System.out.println("----------------------------------------------------");
        for (int i = 0; i < names.length; i++) {
            System.out.printf("%-20s %-10.2f %-10c%n", names[i], scores[i], grades[i]);
        }
    }

    public static void printStatistics(double max, double min, double average, double stdDev) {
        System.out.println("\n----------------------------------------------------");
        System.out.println("                 Class Statistics");
        System.out.println("----------------------------------------------------");
        System.out.printf("Highest Score:        %.2f%n", max);
        System.out.printf("Lowest Score:         %.2f%n", min);
        System.out.printf("Average Score:        %.2f%n", average);
        System.out.printf("Standard Deviation:   %.2f%n", stdDev);
    }

    public static void searchStudentLoop(String[] names, double[] scores, char[] grades, Scanner input) {
        System.out.println("\nSearch for students by name. Type 'exit' to stop.");

        while (true) {
            System.out.print("\nEnter student name: ");
            String query = input.nextLine();

            if (query.equalsIgnoreCase("exit")) break;

            boolean found = false;
            for (int i = 0; i < names.length; i++) {
                if (names[i].equalsIgnoreCase(query)) {
                    System.out.println("\nStudent Found!");
                    System.out.println("Name:  " + names[i]);
                    System.out.println("Score: " + scores[i]);
                    System.out.println("Grade: " + grades[i]);
                    found = true;
                    break;
                }
            }
            if (!found) System.out.println("Student not found.");
        }
    }
}
