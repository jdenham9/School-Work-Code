package numbers.txt;

// Student Name: Jason Denham
// LSU ID: 894827332

import java.io.File;
import java.io.PrintWriter;
import java.util.Random;


public class numberstxt {

	public static void main(String[] args) {
		
		try {
			File file = new File("numbers.txt");
			PrintWriter writer = new PrinterWriter(file);
			
			Random rand = new Random();
			
		
		}
		
	
		
	}
	
}
		

	


