package CakeShop;

// Name: Jason Denham
// LSU ID: 894827332

public class Cake implements Comparable<Cake> {
	
	private int tiers;
	private String flavor;
	private double price;

	public Cake(int tiers, String flavor, double price) {
		this.tiers = tiers;
		this.flavor = flavor;
		this.price = price; 
	}
		public int getTiers() {
			return tiers;
		}
		public String getFlavor() {
			return flavor;
		}
		public double getPrice() {
			return price;
		}
		
		
		public void setPrice(double p){
			price = p;
		}

		public void printCard(){
			System.out.printf("A %d tier %s cake \t\t $%.2f\n", tiers, flavor, price);
		}

		public int compareTo(Cake c) {
			int flavorCompare = this.flavor.compareTo(c.flavor);
			
			if (flavorCompare != 0) {
				return flavorCompare;
			}
			
			return Double.compare(this.price, c.price);
		}

	


	}


