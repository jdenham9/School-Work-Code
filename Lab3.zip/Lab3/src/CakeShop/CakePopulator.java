package CakeShop;

// Name: Jason Denham
// LSU ID: 894827332

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class CakePopulator {
	public static void main(String[] args) throws FileNotFoundException{
		File outFile = new File("./CakeShop/cakes.csv");
		PrintWriter out = new PrintWriter(outFile);

		String[] flavors = {"Lemon", "Vanilla", "Chocolate", "Red Velvet", "Strawberry", "Carrot"};

		out.print("Tiers,Flavor,Price");

		for(int i = 0; i < 50; i++){
			int numTiers = (int)(Math.random()*5+1);
			String flavor = flavors[(int)(Math.random()*flavors.length)];
			double price = (Math.random()*10+20)*numTiers;
			out.printf("%n%d,%s,%.2f", numTiers, flavor, price);
		}

		out.close();
	}

}

