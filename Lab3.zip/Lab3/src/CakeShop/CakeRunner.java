package CakeShop;

// Name: Jason Denham
// LSU ID: 894827332

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CakeRunner {
	public static void main(String[] args) throws FileNotFoundException{
		Inventory cakes = new Inventory();

		File inFile = new File("./cakes.csv");
		Scanner in = new Scanner(inFile);

		in.nextLine();

		while(in.hasNextLine()){
			String line = in.nextLine();
			String[] values = line.split(",");

			cakes.addCake(new Cake(Integer.parseInt(values[0]), values[1], Double.parseDouble(values[2])));
		}

		cakes.listInventory();

		in.close();
	}

}


	


