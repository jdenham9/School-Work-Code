package CakeShop;

// Name: Jason Denham
// LSU ID: 894827332

import java.util.ArrayList;
import java.util.Collections;

public class Inventory {
	private ArrayList<Cake> cakes;

	public Inventory(){
		cakes = new ArrayList<>();
	}

	public void addCake(Cake cake) {
		cakes.add(cake);
	
	}
	public void listInventory() {
		Collections.sort(cakes);
		
	
	for (Cake cake : cakes) {
		cake.printCard();
	}
	
}

}