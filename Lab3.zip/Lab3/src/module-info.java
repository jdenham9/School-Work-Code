/**
 * 
 */
/**
 * 
 */
module Lab3 {
}