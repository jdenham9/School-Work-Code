package CakeShop;

// Name: Jason Denham
// LSU ID: 894827332

	import java.io.File;
	import java.io.FileNotFoundException;
	import java.util.Scanner;

	public class CakeRunner {
		public static void main(String[] args) throws FileNotFoundException{
			Inventory cakes = populate();

			char option = 'a';
			Scanner in = new Scanner(System.in);
			while(option != 'q'){
				menuList();

				option = in.next().charAt(0);
				switch(option){
					case '1':
						promptAddCake(cakes);
						break;
					case '2':
						cakes.listInventory();
						break;
					case '3':
						promptChangePrice(cakes);
						break;
				}
			}

			cakes.saveInventory();
			in.close();
		}

		public static void menuList(){
			System.out.println("Please select one of the following:");
			System.out.println("\t1- Make a new cake");
			System.out.println("\t2- List Inventory");
			System.out.println("\t3- Change Price");
			System.out.println("\tq- Exit");
		}

		public static Inventory populate() throws FileNotFoundException {
			Inventory cakes = new Inventory();

			File inFile;
			Scanner in = null;

			try {
				inFile = new File("inventory.csv");
				in = new Scanner(inFile);
			} catch (FileNotFoundException e) {
				inFile = new File("cakes.csv");
				try {
					in = new Scanner(inFile);
				} catch (FileNotFoundException ex) {
					System.out.println("Error: cakes.csv not found: Exiting.");
					System.exit(1);
					
				}

				

			in.nextLine();

			while(in.hasNextLine()){
				String line = in.nextLine();
				String[] values = line.split(",");

				cakes.addCake(new Cake(Integer.parseInt(values[0]), values[1], Double.parseDouble(values[2])));
			}

			in.close();
		
			}
			return cakes;
		}

		public static void promptAddCake(Inventory i) {
			Scanner in = new Scanner(System.in);
			
			System.out.print("Enter the number of tiers: ");
			int tiers = in.nextInt();
			in.nextLine();
			
			System.out.print("What's the flavor of the cake? ");
			String flavor = in.nextLine();
			
			System.out.print("Enter the price: ");
			double price = in.nextDouble();
			in.nextLine();
			
			
			i.addCake(new Cake(tiers, flavor, price));
				
				System.out.println("Cake has been added.");
		}
				
			
			
			

		

		public static void promptChangePrice(Inventory i) {
			Scanner in = new Scanner(System.in);
			
			System.out.print("Enter the percent multiplier (e.g., 1.10 for +10%): ");
			double percent = in.nextDouble();
			in.nextLine();
			
			i.priceChange(percent);
			
			System.out.println("The prices have been updated.");
			
		in.close();
		

		

	}

}
