package CakeShop;

// Name: Jason Denham
// LSU ID: 894827332

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

public class Inventory {
	private ArrayList<Cake> cakes;
	
	public Inventory() {
		cakes = new ArrayList<>();
	}
	
	public void addCake(Cake c) {
		cakes.add(c);
	}
	
	public void listInventory() {
		Collections.sort(cakes);
		for(Cake cake : cakes) {
			cake.printCard();
		}
	}
	
	public void priceChange(double percent) {
		for (Cake c : cakes) {
			c.setPrice(c.getPrice() * percent);
		
		}
	}
	
	public void saveInventory() throws FileNotFoundException {
		try {
			PrintWriter pw = new PrintWriter(new File("inventory.csv"));
			
			pw.println("Tiers, Flavor, Price");
			
			for (Cake c : cakes) {
				pw.println(c.getTiers() + "," + c.getFlavor() + "," + c.getPrice());
			}
			
			pw.close();
			System.out.println("The inventory has now been saved.");
		} catch (FileNotFoundException e) {
			System.out.println("There was an issue saving the inventory.");
			}
		}
	}
		
		
		
	


