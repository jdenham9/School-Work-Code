/**
 * 
 */
/**
 * 
 */
module Lab4 {
}