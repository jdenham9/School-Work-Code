package singlecorescheduler;

/**
 * A application to simulate a non-preemptive scheduler for a single-core CPU
 * using a heap-based implementation of a priority queue
 * @author William Duncan, YOUR NAME
 * @see PQueue.java, PCB.java
 * <pre>
 * DATE: LAST DATE MODIFIED
 * File:SingleCoreScheduler.java
 * Course: csc 3102
 * Programming Project # 1
 * Instructor: Dr. Duncan
 * Usage: SingleCoreScheduler <number of cylces> <-R or -r> <probability of a  process being created per cycle>  or,
 *        SingleCoreScheduler <number of cylces> <-F or -f> <file name of file containing processes>,
 *        The simulator runs in either random (-R or -r) or file (-F or -f) mode 
 * </pre>
 */


import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

import package1.PQueueException;
import package1.PQueue;

public class SingleCoreScheduler

{
	
    /**
     * Single-core processor with non-preemptive scheduling simulator    
     * @param args an array of strings containing command line arguments
     * args[0] - number of cyles to run the simulation
     * args[1] - the mode: -r or -R for random mode and -f or -F for file mode
     * args[2] - if the mode is random, this entry contains the probability that
     * a process is created per cycle and if the simulator is running in
     *           file mode, this entry contains the name of the file containing the 
     *           the simulated jobs. In file mode, each line of the input file is  
     *           in this format: 
     * <process ID> <priority value> <cycle of process creation> <time required to execute> 
     */
    public static void main(String []args) throws PQueueException, IOException
    {
        if (args.length != 3)
        {
            System.out.println("Usage: SingleCoreScheduler <number of cylces> <-R or -r> <probability of a  process being created per cycle>  or ");
            System.out.println("       SingleCoreScheduler <number of cylces> <-F or -f> <file name of file containing processes>");
            System.out.println("The simulator runs in either random (-R or -r) or file (-F or -f) mode.");
            System.exit(1);
        }
		
        int cycles = 0;
        
        try
        {
        	cycles = Integer.parseInt(args[0]);
        }
        
        catch (NumberFormatException e)
        {
        	System.out.println("The number of cycles must be a positive integer.");
        	
        }
        
        
        if (cycles <= 0)
        {
        	System.out.println("The number of cycles must be a positive integer.");
        	System.exit(1);
        }
        
        String mode = args[1];
        
        if (!mode.equals("-r") && !mode.equals("-R") && !mode.equals("-f") && !mode.equals("-F"))
        {
        	System.out.println("Invalid mode. Please use -r/-R for the random mode or -f/-F for the file mode.");
        	return;
        }
        
        Random random = new Random(System.currentTimeMillis());
        
        Comparator<PCB> pcbComparator = (x, y) ->
        {
        	if (x.getPriority() != y.getPriority())
        	{
        		return Integer.compare(x.getPriority(), y.getPriority());
        	}
        	
        	return Integer.compare(x.getArrival(), y.getArrival());
        };
        
        PQueue<PCB> readyQ = new PQueue<>(pcbComparator);
        
        Scanner fileScanner = null;
        PCB nextFileJob = null;
        
        if (mode.equals("-f") || mode.equals("-F"))
        		{
        	fileScanner = new Scanner(new FileReader(args[2]));
        	
        	if (fileScanner.hasNextInt())
        	{
        		int pid = fileScanner.nextInt();
        		int priority = fileScanner.nextInt();
        		int arrival = fileScanner.nextInt();
        		int burst = fileScanner.nextInt();
        		
        		nextFileJob = new PCB(pid, priority, 0, arrival, burst);
        	}
        	
        	else
        	{
        		double probability;
        		
        		try
        		{
        			probability = Double.parseDouble(args[2]);
        			
        		}
        		
        		catch (NumberFormatException e)
        		{
        			System.out.println("The probability has to be a number between 0.0 and 1.0");
        			return;
        			
        		}
        		
        		if (probability < 0.0 || probability > 1.0)
        		{
        			System.out.println("The probability has to be a number between 0.0 and 1.0");
        			return;
        		}
        	}
        	
        		}
        PCB current = null;
        
        int totalCreated = 0;
        int totalWait = 0;
        int totalBurst = 0;
        int nextPid = 1;
        
        for (int cycle = 0; cycle < cycles; cycle++)
        {
        	System.out.println("*** Cycle #: " + cycle);
        	
        	if (current == null)
        	{
        		if (readyQ.isEmpty())
        		{
        			System.out.println("CPU is idle");
        		}
        		else 
        		{
        			current = readyQ.remove();
        			
        			current.execute();
        			current.setStart(cycle);
        			current.setWait(cycle - current.getArrival());
        			
        			totalWait += current.getWait();
        			
        			System.out.println("Process #" + current.getPid() + " is executing correctly.");
        			
        		}
        	}
        	
        	else if (cycle - current.getStart() >= current.getBurst())
        	{
        		System.out.println("Process #" + current.getPid() + " has been terminated");
        		
        		current = null;
        	}
        	else
        	{
        		System.out.println("Process #" + current.getPid() + " is executing currently.");
        	}
        	
        	if (mode.equals("-f") || mode.equals("-F"))
        	{
        		if (nextFileJob != null && nextFileJob.getArrival() == cycle)
        		{
        			readyQ.add(nextFileJob);
        			
        			System.out.println("Adding the job with pid #" + nextFileJob.getPid() + " and priority" + nextFileJob.getPriority() + " and burst" + nextFileJob.getBurst() + ".");
        			
        			totalCreated++;
        			totalBurst += nextFileJob.getBurst();
        			
        			if (fileScanner.hasNextInt())
        			{
        				int pid = fileScanner.nextInt();
        				int priority = fileScanner.nextInt();
        				int arrival = fileScanner.nextInt();
        				int burst = fileScanner.nextInt();
        				
        				nextFileJob = new PCB(pid, priority, 0, arrival, burst);
        			}
        			
        			else
        			{
        				nextFileJob = null;
        			}
        		}
        	}
        		else
        		{
        			double probability = Double.parseDouble(args[2]);
        			
        			if (random.nextDouble() < probability)
        			{
        				int priority = random.nextInt(40) - 20;
        				int burst = random.nextInt(100) + 1;
        				
        				PCB newJob = new PCB(nextPid++, priority, 0, cycle, burst);
        				
        				readyQ.add(newJob);
        				
        				System.out.println("Adding the job with pid #" + newJob.getPid() + " and priority " + newJob.getPriority() + " and burst " + newJob.getBurst() + ".");
        				
        				totalCreated++;
        				totalBurst += burst;
        				
        			}
        			else
        			{
        				System.out.println("There is now new job this cycle");
        						
        			}
        		}
        		
        	}
        if (fileScanner != null)
        {
        	fileScanner.close();
        }
        
        System.out.println("The average number of process created per cycle is" + ((double) totalCreated / cycles) + ". ");
        
        	{
        if (totalCreated > 0)
        {
        	System.out.println("The throughput is" + ((double) totalBurst / totalCreated) + "cycles. ");
        	
        	System.out.println("The average wait time per process " + ((double) totalWait / totalCreated) + ".");
        }
        
        else
        {
        	System.out.println("The throughput is 0.0 cycles");
        	System.out.println("The average wait time per process is 0.0");
        }
    }
        {
}


	
	{
        
        
     
        
	}
        }
    {
    }
    }
    
        
   
        
    




	













