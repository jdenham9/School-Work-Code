package dendrologist;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Comparator;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * A testbed for an augmented implementation of an AVL tree
 * @author William Duncan, YOUR NAME
 * @see AVLTreeAPI
 * <pre>
 * Date: DATE LAST MODIFIED
 * Course: CSC 3102 
 * Programming Project # 2
 * Instructor: Dr. Duncan 
 * </pre>
 */
public class Dendrologist
{
    public static void main(String[] args) throws FileNotFoundException 
    {
        String usage = "Dendrologist <order-code> <command-file>\n";
        usage += "  <order-code>:\n";
        usage += "  0 ordered by increasing string length, primary key, and reverse lexicographical order, secondary key\n";
        usage += "  -1 for reverse lexicographical order\n";
        usage += "  1 for lexicographical order\n";
        usage += "  -2 ordered by decreasing string\n";
        usage += "  2 ordered by increasing string\n";
        usage += "  -3 ordered by decreasing string length, primary key, and reverse lexicographical order, secondary key\n";
        usage += "  3 ordered by increasing string length, primary key, and lexicographical order, secondary key\n";      
        if (args.length != 2)
        {
            System.out.println(usage);
            throw new IllegalArgumentException("There should be 2 command line arguments.");
        }
        
        int orderCode;
        try
        {
        	orderCode = Integer.parseInt(args[0]);
        }
        catch (NumberFormatException ex)
        {
        	System.out.println(usage);
        	throw new IllegalArgumentException("The order code has to be an integer.", ex);
        }
        
        Comparator<String> comparator;
        switch (orderCode)
        {
        	case 0:
        		comparator = (a, b) ->
        		{
        			int result = Integer.compare(a.length(), b.length());
        			return result != 0 ? result : b.compareTo(a);
        			
        		};
        		break;
        	case -1:
        		comparator = (a, b) -> b.compareTo(a);
        		break;
        	case 1:
        		comparator = String::compareTo;
				break;
        	case -2:
        		comparator = (a, b) -> b.compareTo(a);
				break;
			case 2:
				comparator = String::compareTo;
				break;
        	case -3:
        		comparator = (a, b) ->
        		{
        			int result = Integer.compare(b.length(), a.length());
        			return result != 0 ? result : b.compareTo(a);
        		
        		};
        		break;
        	case 3:
        		comparator = (a, b) ->
        		{
        			int result = Integer.compare(a.length(), b.length());
        			return result != 0 ? result : a.compareTo(b);
        			
        		};
        		break;
        	default:
        		System.out.println(usage);
        		throw new IllegalArgumentException("Invalid order code: " + orderCode);
        }
        
        AVLTree<String> tree = new AVLTree<>(comparator);
        
        try (Scanner input = new Scanner(new FileReader(args[1])))
        {
        	while (input.hasNextLine())
        	{
        		String line = input.nextLine().trim();
        		if (line.isEmpty() || line.startsWith("#"))
        			continue;
        		
        		String[] parts = line.split("\\s+", 2);
        		String command = parts[0].toLowerCase();
        		String value = parts.length > 1 ? parts[1].trim() : "";
        		
        		switch (command)
        		{
        		case "insert":
        			if (value.isEmpty())
        				System.out.println("insert requires value");
        			else
        				tree.insert(value);
        			break;
        		case "delete":
        		case "remove":
        			if (value.isEmpty())
        				System.out.println(command + " requires value");
        			else
        				tree.remove(value);
        			break;
        		case "traverse":
        			tree.traverse(item -> { System.out.println(item); return null; });
        			break;
        		case "paths":
        			for (String path : tree.genPaths())
        				System.out.println(path);
        			break;
        		case "stats":
        			System.out.println("Size: " + tree.size());
        			System.out.println("Height: " + tree.height());
        			System.out.println("Full nodes: " + tree.fullCount());
        			System.out.println("Fibonacci: " + tree.isFibonacci());
        			break;
        		default:
        			System.out.println("Unknown command: " + line);
        			break;
        		}
        	}
        }
    }   
}
