package StackProblems;

// Name: Jason Denham
// LSU ID; 894827332

import java.util.Stack;

public class StackProblemsRunner {
    public static void main(String[] args) {
		testPalindrome();

		testBalanced();

		testExpression();
    }

	public static void testPalindrome(){
		String[] testCases = {"racecar", "ABBA", "DeTarTrAtEd", "Taco cat", "A man, a plan, a canal, Panama!", "", "a", "steve", "aaaaba", "abc"};
		boolean[] expectedResults = {true, true, true, true, true, true, true, false, false, false};
		String failedCases = "";
		int numFails = 0;

		for(int i = 0; i < testCases.length; i++){
			boolean result = isPalindrome(testCases[i]);
			if(result != expectedResults[i]){
				numFails++;
				failedCases += "\t-> " + testCases[i] + "\n\t\tExpected :: " + expectedResults[i] + "\n\t\tGot :: "+ result + "\n";
			}
		}

		System.out.printf("Passed %d cases. Failed %d cases.%nFailed Cases:%n%s", testCases.length - numFails, numFails, failedCases);
	}

	public static void testBalanced(){
		String[] testCases = {"({[(([{()}]))]})", "[]{}({}{}[]){}[]", "{}{}({()})", "", "()", "{", "((){}{}", "}", "[([{}]))", "[]{}({{}}[}]){}[]"};
		boolean[] expectedResults = {true, true, true, true, true, false, false, false, false, false};
		String failedCases = "";
		int numFails = 0;

		for(int i = 0; i < testCases.length; i++){
			boolean result = isBalancedExpression(testCases[i]);
			if(result != expectedResults[i]){
				numFails++;
				failedCases += "\t-> " + testCases[i] + "\n\t\tExpected :: " + expectedResults[i] + "\n\t\tGot :: "+ result +"\n";
			}
		}

		System.out.printf("Passed %d cases. Failed %d cases.%nFailed Cases:%n%s", testCases.length - numFails, numFails, failedCases);
	}

	public static void testExpression(){
		String[] testCases = {"42+351-*+", "545*+5/", "222^^", "54^52^/5/", "99*7+8/56-*56++"};
		int[] expectedResults = {18, 5, 16, 5, 0};
		String failedCases = "";
		int numFails = 0;

		for(int i = 0; i < testCases.length; i++){
			int result = evaluateExpression(testCases[i]);
			if(result != expectedResults[i]){
				numFails++;
				failedCases += "\t-> " + testCases[i] + "\n\t\tExpected :: " + expectedResults[i] + "\n\t\tGot :: "+ result +"\n";
			}
		}

		System.out.printf("Passed %d cases. Failed %d cases.%nFailed Cases:%n%s", testCases.length - numFails, numFails, failedCases);
	}

    public static boolean isPalindrome(String s)
    {
        Stack<Character> palindrome = new Stack<>();

		s = s.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();		
		
		for(char c : s.toCharArray())
			palindrome.push(c);
		for(char c : s.toCharArray())
			if(palindrome.pop() != c) return false;
				
				
	
	return true;
    }

    public static boolean isBalancedExpression(String s)
    {
        Stack<Character> exp = new Stack<>();
        
		for(char c : s.toCharArray())
			if(c == '(' || c == '{' || c == '[') {
				exp.push(c);
			}
			else if(c == ')' || c == '}' || c == ']') {
				if(exp.isEmpty()) return false;
		
		char top = exp.pop();
		
		if(c == ')' && top != '(') return false;
		if(c == '}' && top != '{') return false;
		if(c == ']' && top != '[') return false;
			
			}
    

		return exp.isEmpty();
    }

    public static int evaluateExpression(String s)
    {
        Stack<Integer> exp = new Stack<>();

		int a;
		
		for(char c : s.toCharArray()) {
			if(Character.isDigit(c)) {
				exp.push(c - '0');
		  } else {
				int right = exp.pop();
				int left = exp.pop();
				 
				switch(c) 
				{	case '+': a = left + right; break;
					case '-': a = left - right; break;
					case '*': a = left * right; break;
					case '/': a = left / right; break;
					case '^': a = (int)Math.pow(left, right); break;
					default: return -1;
				}
				
				exp.push(a);
				
		  }
		}
		

		return exp.pop();
		  
			
				}
    	}


    

		

			

	
			
				
			


