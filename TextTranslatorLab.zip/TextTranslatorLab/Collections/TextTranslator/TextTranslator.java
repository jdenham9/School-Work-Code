package TextTranslator;

// Name: Jason Denham
// LSU ID: 894827332

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;

public class TextTranslator {

	public static void main(String[] args) {
		
		Map<String, String> acronyms = loadAcronyms("acronyms.txt");
		
		Scanner in = new Scanner(System.in).useDelimiter("\\n");
		System.out.print("Enter a sentence: ");
		
		String userInput = in.next();
		
		String translated = translateSentence(userInput, acronyms);
		
		System.out.println(translated);
	}
	
	public static Map<String, String> loadAcronyms(String filename) {
		Map<String, String> map = new HashMap<>();
		
		try {
			Scanner fileScanner = new Scanner(new File(filename));
			
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine().trim();
				if (line.isEmpty()) continue;
				
				String[] parts = line.split("\t", 2);
				if (parts.length == 2) {
					String key = parts[0].trim().toLowerCase();
					String value = parts[1].trim();
					map.put(key, value);
					
					
				}
			}
			fileScanner.close();
	 } catch (FileNotFoundException e) {
		  System.out.println("File not found: " + filename);
		  System.out.print("Make sure acronyms.txt is in the correct location.");
		  
	  }
		
		return map;
	}
	
	public static String translateSentence(String input, Map<String, String> acronyms) {
		String[] words = input.split("\\s+");
		StringBuilder result = new StringBuilder();
		
		for (String word : words) {
			String translated = translateWord(word, acronyms);
			result.append(translated).append(" ");
		}
		
		return result.toString().trim();
	}
	
	public static String translateWord(String word, Map<String, String> acronyms) {
		StringBuilder punctuation = new StringBuilder();
		
		int i = word.length() - 1;
		while (i >= 0 && !Character.isLetterOrDigit(word.charAt(i))) {
			punctuation.insert(0, word.charAt(i));
			i--;
			
		}
		
		String core = word.substring(0, i + 1);
		
		String lower = core.toLowerCase();
		
		if (acronyms.containsKey(lower)) {
			core = acronyms.get(lower);
			
		}
		
		return core + punctuation.toString();
	}
	
	}
	



