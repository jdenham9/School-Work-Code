/**
 * 
 */
/**
 * 
 */
module TextTranslatorLab {
}