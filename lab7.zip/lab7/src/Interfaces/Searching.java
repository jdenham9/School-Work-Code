package Interfaces;

// Name: Jason Denham
// LSU ID: 894827332

public interface Searching{
	static <T extends Comparable<T>> int search(T[] arr, T elem){
		return -1;
	}
}
