package Interfaces;

// Name: Jason Denham
// LSU ID: 894827332

public interface Sorting<SORTABLE> {
	public static <T extends Comparable<T>> void sort(T[] arr){}
}
