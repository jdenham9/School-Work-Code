package SearchingAlgorithms;

// Name: Jason Denham
// LSU ID: 894827332

import Interfaces.Searching;

public class BinarySearch implements Searching{
	public static <T extends Comparable<T>> int search(T[] arr, T elem){
		for(int left = 0, right = arr.length-1; left <= right;){
			int mid = (right+left)/ 2;

			if(arr[mid].compareTo(elem) == 0){
				return mid;
			}
			else if(arr[mid].compareTo(elem) > 0){
				right = mid - 1;
			}
			else{
				left = mid + 1;
			}
		}

		return -1;
	}
}

