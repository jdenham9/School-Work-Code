package SearchingAlgorithms;

// Name: Jason Denham
// LSU ID: 894827332

import Interfaces.Searching;

public class LinearSearch implements Searching{
	public static <T extends Comparable<T>> int search(T[] arr, T elem){

		for(int i = 0; i < arr.length; i++){
			if(arr[i].compareTo(elem) == 0){
				return i;
			}
		}

		return -1;
	}
}

