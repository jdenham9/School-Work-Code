package SortingAlgorithms;

// Name: Jason Denham
// LSU ID: 894827332

import Interfaces.Sorting;

public class BubbleSort implements Sorting<SORTABLE> {
	public static <T extends Comparable<T>> void sort(T[] arr){
		for(int i = 0; i < arr.length-1; i++){

			for(int j = 0; j<arr.length-i-1; j++){

				if(arr[j].compareTo(arr[j+1]) > 0){
					T temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
	}
}

