package SortingAlgorithms;

// Name: Jason Denham
// LSU ID: 894827332

import Interfaces.Sorting;

public class InsertionSort implements Sorting<SORTABLE> {
	public static <T extends Comparable<T>> void sort(T[] arr){
		int i;
		T key;
		int j;

		for (i = 1; i < arr.length; i++){
			key = arr[i];
			j = i - 1;

			while (j >= 0 && arr[j].compareTo(key) > 0){
				arr[j + 1] = arr[j];
				j = j - 1;
			}

			arr[j + 1] = key;
		}
	}
}

