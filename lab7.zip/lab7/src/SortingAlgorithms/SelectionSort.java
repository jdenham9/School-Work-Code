package SortingAlgorithms;

// Name: Jason Denham
// LSU ID: 894827332

import Interfaces.Sorting;

public class SelectionSort implements Sorting<SORTABLE> {
	public static <T extends Comparable<T>> void sort(T[] arr){
		// TODO - make this work with Generic type T
		for(int i=0; i< arr.length-1; i++){
			int minIndex = i;

			for(int j=i+1; j<arr.length; j++){
				if(arr[j].compareTo(arr[minIndex]) < 0){
					minIndex =j;
				}
			}

			T smallerNumber = arr[minIndex];
			arr[minIndex] = arr[i];
			arr[i] = smallerNumber;
		}
	}
}