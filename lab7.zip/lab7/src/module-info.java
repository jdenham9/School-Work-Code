/**
 * 
 */
/**
 * 
 */
module lab7 {
}