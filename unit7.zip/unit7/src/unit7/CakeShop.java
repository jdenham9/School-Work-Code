package unit7;

// Name: Jason Denham
// LSU: 894827332

public class CakeShop {
	
	String flavor;
	int tiers;
	double price;
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void printCard() {
		System.out.printf("A %d tier %s cake\t\t$%.2f%n", tiers, flavor, price);
	}

	public static void main(String[] args) {
		
		Cake birthdayCake = new Cake();
		birthdayCake.flavor = "Chocolate";
		birthdayCake.tiers = 1;
		birthdayCake.setPrice(30.50);
		
		Cake weddingCake = new Cake();
		weddingCake.flavor = "Vanilla";
		weddingCake.tiers = 4; 
		weddingCake.setPrice(299.99);
		
		Cake graduationCake = new Cake();
		graduationCake.flavor = "Carrot";
		graduationCake.tiers = 2;
		graduationCake.setPrice(47.75);
		
		birthdayCake.printCard();
		weddingCake.printCard();
		graduationCake.printCard();








	}

}
