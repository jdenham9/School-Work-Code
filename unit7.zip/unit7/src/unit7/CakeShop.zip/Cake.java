package unit7;

// Name: Jason Denham
// LSU ID: 894827332

public class Cake {
	
	private String flavor;
	private int tiers;
	private double price;
	
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	} 	

	public void setTiers(int tiers) {
		this.tiers = tiers;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	public void printCard() {
		System.out.printf("A %d tier %s cake\t\t$%.2f%n", tiers, flavor, price);
	}

		

	}


