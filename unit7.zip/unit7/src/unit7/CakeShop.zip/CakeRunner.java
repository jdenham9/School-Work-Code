package unit7;

// Name: Jason Denham
// LSU ID: 894827332

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CakeRunner {

	public static void main(String[] args) throws FileNotFoundException {
		
		File file = new File("cakes.csv");
		Scanner input = new Scanner(file);
		
		while (input.hasNextLine()) {
			String line = input.nextLine();
			String[] parts = line.split(",");
			
			Cake cake = new Cake();
			cake.setFlavor(parts[0].trim());
			cake.setTiers(Integer.parseInt(parts[1].trim()));
			cake.setPrice(Double.parseDouble(parts[2].trim()));
			
			cake.printCard();
		}
		
		input.close();
		
		
		
		Cake birthdayCake = new Cake();
		birthdayCake.setFlavor("Chocolate");
		birthdayCake.setTiers(1);
		birthdayCake.setPrice(30.50);
		
		Cake weddingCake = new Cake();
		weddingCake.setFlavor("Vanilla");
		weddingCake.setTiers(4);
		weddingCake.setPrice(299.99);
		
		Cake graduationCake = new Cake();
		graduationCake.setFlavor("carrot");
		graduationCake.setTiers(2);
		graduationCake.setPrice(47.75);
		
		birthdayCake.printCard();
		graduationCake.printCard();
		weddingCake.printCard();
		
	
		

	}

}
