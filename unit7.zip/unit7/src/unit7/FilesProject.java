package unit7;

// Name: Jason Denham
// LSU ID: 894827332

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;

public class FilesProject {
	
		public static void main(String[] args) {
			Random rand = new Random();
			
			try {
				PrintWriter writer = new PrintWriter("numbers.txt");
						
			for (int i = 0; i < 1000; i++) {
				double number = rand.nextInt(1000) + rand.nextFloat();
				writer.printf("%.2f\n", number);
				
				
			}
			writer.close();
			
			} catch (Exception e) {
				System.out.println("Could not make the file.");
			}
		}

}
