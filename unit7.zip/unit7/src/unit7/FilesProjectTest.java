package unit7;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FilesProjectTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
